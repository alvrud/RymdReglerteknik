% Definition of the process and time scale
G=tf(4,[26 14 1]);
t=0:0.1:50;
y=step(G,t);
idx=find(y>=0.63*4, 1 );
y63=y(idx);
t63=t(idx);

%% Plot the step response of the system
figure(1)
clf
set(gcf,'name','Step response G')
setfig(gcf,16,8)
line(t63,y63+0.5,'marker','*','color','r')
line(t,y+0.5);
line([0,50],[4.5,4.5],'linestyle','--','color','k');
line([0,50],[0.5,0.5],'linestyle','--','color','k');
line([0,50],[0.5,0.5],'linestyle','--','color','k');
line([1.3,18.5],[0.5,4.5],'linestyle','--','color','k');
line([18.5,18.5],[0,4.5],'linestyle',':','color','k');
line([1.3,1.3],[0,0.5],'linestyle',':','color','k');
line([t63,t63],[0,y63+0.5],'linestyle',':','color','k');
text(t63-1.5,-0.5,'L+t_{63%}');
text(1.2,-0.43,'L');
text(17,-0.43,'L+\tau');
ylim([0,5])
xlabel('t');
ylabel('y(t)');
lines=get(gca,'children');
lines=lines(end:-1:1);
set(lines(2),'linewidth',2)
set(gca,'children',lines);
box on
graygrid(gcf,0.7);

%% Approximated first order time delay system
G1=tf(4,[17.2 1]);
G1.iodelay=1.3;
G2=tf(4,[12.9 1]);
G2.iodelay=1.3;
yG1=step(G1,t);
yG2=step(G2,t);
figure(2)
clf
set(gcf,'name','Approximated process')
setfig(gcf,16,8)
plot(t,yG1+0.5,t,y+0.5,t,yG2+0.5);
ylim([0,5]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',lines(end:-1:1));
graygrid(gcf,0.7);

%% Quarter ratio decay
R=4/17.2;
L=1.3;
PID_QDR1=tf([0.6/(R*L*L),1.2/(R*L),0.6/(R*L*L)],[1 0]);
R=4/12.9;
L=1.3;
PID_QDR2=tf([0.6/(R*L*L),1.2/(R*L),0.6/(R*L*L)],[1 0]);
GD=series(G,PID_QDR1);
T=feedback(GD,1);
yQDR1=step(T,t);
GD=series(G,PID_QDR2);
T=feedback(GD,1);
yQDR2=step(T,t);
figure(3)
clf
set(gcf,'name','PID Quarter Decay Ratio')
setfig(gcf,16,8)
plot(t,yQDR1,t,t*0+1,t,yQDR2);
ylim([0,2]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
graygrid(gcf,0.7);

%% Ultimate sensitivity PID
Ku1=margin(G1);
T=feedback(Ku1*G1,1);
yUT=step(T,t);
figure(4)
clf
set(gcf,'name','Ultimate sensitivity test')
setfig(gcf,16,8)
plot(t,yUT,'b');
ylim([-0.2,2.2]);
xlim([0,20])
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
graygrid(gcf,0.7);

%% PID from Ultimate sensitivity test
% Time difference between peaks and reuse Ku from above.
Pu1=8.4-3.3;
PID_UT1=tf([1.6*Ku1/(0.125*Pu1), 1.6*Ku1, 1.6*Ku1/(0.5*Pu1)],[1 0]);
GD=series(G,PID_UT1);
T=feedback(GD,1);
yUT=step(T,t);
figure(5)
clf
set(gcf,'name','PID Ultimate sensitivity')
setfig(gcf,16,8)
plot(t,yUT,t,t*0+1);
ylim([0,2]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
graygrid(gcf,0.7);

%% PI med lambda metoden
tau=t63-L;
lambda1=0.2*max([L,tau]);
lambda2=0.6*max([L,tau]);
PI1=tf([tau/(4*(lambda1+L)),1/(4*(lambda1+L))],[1 0]);
PI2=tf([tau/(4*(lambda2+L)),1/(4*(lambda2+L))],[1 0]);
GD=series(G,PI1);
T=feedback(GD,1);
yPI1=step(T,t);
GD=series(G,PI2);
T=feedback(GD,1);
yPI2=step(T,t);
figure(6)
clf
set(gcf,'name','PI Lambda metoden')
setfig(gcf,16,8)
plot(t,yPI1,t,t*0+1,t,yPI2);
ylim([0,2]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
graygrid(gcf,0.7);

%% Discrete vs continuous
td=t(1:20:end);
yd=y(1:20:end);
figure(7)
clf
set(gcf,'name','Discrete vs Continuous')
setfig(gcf,16,8)
plot(t,y,td,yd,'ro');
for i=1:length(td)
    line([td(i),td(i)],[0,yd(i)],'color','r')
end
ylim([0,5]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
graygrid(gcf,0.7);
figure(8)
clf
set(gcf,'name','Discrete vs Continuous')
setfig(gcf,16,8)
plot(td,yd,'bo');
for i=1:length(td)-1
    line([td(i),td(i+1)],[yd(i),yd(i)],'color','r')
end
ylim([0,5]);
xlabel('t')
ylabel('u(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
for i=1:length(td)-1
    line([td(i+1),td(i+1)],[yd(i),yd(i+1)],'color','k')
end
graygrid(gcf,0.7);

