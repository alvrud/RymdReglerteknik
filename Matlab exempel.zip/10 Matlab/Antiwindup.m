%% Saturations and Anti-Windup
% Saturation and no anti-windup
Kanti=0;
sim Antiwindup.slx
figure(1)
clf
axes
colOrder=get(gca,'colororder');
line([0,15],[1.02,1.02],'color',[0.6,0.6,0.6]);
line([0,15],[0.98,0.98],'color',[0.6,0.6,0.6]);
line(y_sim(:,1),y_sim(:,4),'color',colOrder(3,:),'linewidth',1);
line(y_sim(:,1),y_sim(:,2),'color',colOrder(1,:),'linewidth',2);
line(y_sim(:,1),y_sim(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,1.4]);
xlim([0,15]);
xlabel('time (s)')
ylabel('y')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[0,0.2,0.4,0.6,0.8,1,1.2,1.4]);
box on
figure(2)
clf
axes
colOrder=get(gca,'colororder');
line(u_sim(:,1),u_sim(:,2),'color',colOrder(1,:),'linewidth',2);
line(u_sim(:,1),u_sim(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,6]);
xlim([0,15]);
xlabel('time (s)')
ylabel('u')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[1:6]);
box on
figure(3)
clf
axes
colOrder=get(gca,'colororder');
line(e_int(:,1),e_int(:,2),'color',colOrder(1,:),'linewidth',2);
line(e_int(:,1),e_int(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,0.8]);
xlim([0,15]);
xlabel('time (s)')
ylabel('integrator value')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[0:0.1:0.8]);
box on

%% Saturation with Antiwindup
Kanti=0.1;
sim Antiwindup.slx
figure(4)
clf
axes
colOrder=get(gca,'colororder');
line([0,15],[1.02,1.02],'color',[0.6,0.6,0.6]);
line([0,15],[0.98,0.98],'color',[0.6,0.6,0.6]);
line(y_sim(:,1),y_sim(:,4),'color',colOrder(3,:),'linewidth',1);
line(y_sim(:,1),y_sim(:,2),'color',colOrder(1,:),'linewidth',2);
line(y_sim(:,1),y_sim(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,1.4]);
xlim([0,15]);
xlabel('time (s)')
ylabel('y')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[0,0.2,0.4,0.6,0.8,1,1.2,1.4]);
box on
figure(5)
clf
axes
colOrder=get(gca,'colororder');
line(u_sim(:,1),u_sim(:,2),'color',colOrder(1,:),'linewidth',2);
line(u_sim(:,1),u_sim(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,6]);
xlim([0,15]);
xlabel('time (s)')
ylabel('u')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[1:6]);
box on
figure(6)
clf
axes
colOrder=get(gca,'colororder');
line(e_int(:,1),e_int(:,2),'color',colOrder(1,:),'linewidth',2);
line(e_int(:,1),e_int(:,3),'color',colOrder(2,:),'linewidth',2);
ylim([0,0.8]);
xlim([0,15]);
xlabel('time (s)')
ylabel('integrator value')
set(gca,'xtick',[0,2,4,6,8,10,12,14],'ytick',[0:0.1:0.8]);
box on
