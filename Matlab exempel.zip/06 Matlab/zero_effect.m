%% Effect of a zero on the system response
% Script to show the effect of a zero
%
% 2016-04-19, W. Birk, LTU

%% Location of the zero
% First we define the location of the zero using the parameter $a$.
a=-1;

%%
% The resulting transfer functions are then defined as
% $G(s)=G_1(s)+G_2(s)$
%
% 
% $$e^{\pi i} + 1 = 0$$
% 
G=tf([50/a 50],[1 15 50]);
G1=tf((10-a)/a,[0.1 1]);
G2=tf(2*(a-5)/a,[0.2 1]);

% Derive the step responses
t=0:.01:2;
y=step(G,t);
y1=step(G1,t);
y2=step(G2,t);
dcg=dcgain(G);
dcg1=dcgain(G1);
dcg2=dcgain(G2);

% Plot of the responses
figure(1);
clf
subplot(311);
line([min(t);max(t)],[dcg;dcg],'color',[0,0.5,0],'linewidth',1);
line(t,y,'color','b','linewidth',2);
ylabel('y(t)=y_1(t)+y_2(t)')
box on
subplot(312);
line([min(t);max(t)],[dcg1;dcg1],'color',[0,0.5,0],'linewidth',1);
line(t,y1,'color','b','linewidth',2);
ylabel('y_1(t)')
box on
subplot(313);
line([min(t);max(t)],[dcg2;dcg2],'color',[0,0.5,0],'linewidth',1);
line(t,y2,'color','b','linewidth',2);
xlabel('time (sec)')
ylabel('y_2(t)')
box on





