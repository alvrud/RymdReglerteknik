% Script to initialise the car example
%
% W. Birk, 2012-11-09

% Initialise the parameters
Car.m = 1000;   % mass of the car, kg
Car.Cd = 0.5;   % drag coefficient, dimensionless
Car.A = 3;      % projected front area, m^2
Car.v_init = 20;% initial speed, m/s
Car.x_init = 0; % initial position, m

General.g = 9.81;    % gravitational constant, m/(s^2)
General.rho_air = 1.29; % density of air at 1 bar, 0 degrees, kg/(m^3)


% Load the simulink block diagram
car


