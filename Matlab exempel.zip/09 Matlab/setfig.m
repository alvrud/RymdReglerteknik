function setfig(f,w,h)

set(f,'paperpositionmode','auto');
set(f,'units','centimeters');

pos=get(f,'position');
pos(3)=w;
pos(4)=h;
set(f,'position',pos);


