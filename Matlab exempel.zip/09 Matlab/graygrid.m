function graygrid(f,x)
% Creates a gray grid with solid line style

if nargin==1
    x=0.6;
end

ca=get(f,'currentaxes');
xo=get(ca,'xcolor');
yo=get(ca,'ycolor');
set(ca,'gridlinestyle','-','xcolor',[x,x,x],'ycolor',[x,x,x]);
grid on

na=copyobj(ca,f);
set(na,'xcolor',xo,'ycolor',yo,'xgrid','off','ygrid','off','color','none');

set(f,'currentaxes',na);

%end
