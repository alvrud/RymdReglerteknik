%% Definition of the process and time scale
G=tf(1.5,[1 0.4 1.5]);
Gw=2/3;
t=(0:0.1:30);
y=step(G,t);

%% Plot the step response of the system
figure(1)
clf
set(gcf,'name','Step response G')
plot(t,y,t,t*0+1);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);

%% P Control, Analysis of the transfer functions.
D=tf(10,1);
L=series(G,D);
T=feedback(L,1);
S=1-T;
Tw=series(Gw*G,S);
yT=step(T,t);
yW=step(Tw,t);
figure(2)
clf
set(gcf,'name','P Control T')
plot(t,yT,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);

figure(3)
clf
set(gcf,'name','P Control Tw')
plot(t,yW,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
yT_P=yT;

%% PI Control, Analysis of the transfer functions.
D=tf([3 0.6],[1 0]);
L=series(G,D);
T=feedback(L,1);
S=1-T;
Tw=series(Gw*G,S);
yT=step(T,t);
yW=step(Tw,t);
figure(4)
clf
set(gcf,'name','PI Control T')
plot(t,yT,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
figure(5)
clf
set(gcf,'name','PI Control Tw')
plot(t,yW,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
yT_PI=yT;

%% PD Control, Analysis of the transfer functions.
D=tf([3 3],1);
L=series(G,D);
T=feedback(L,1);
S=1-T;
Tw=series(Gw*G,S);
yT=step(T,t);
yW=step(Tw,t);
figure(6)
clf
set(gcf,'name','PD Control T')
plot(t,yT,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
figure(7)
clf
set(gcf,'name','PD Control Tw')
plot(t,yW,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
yT_PD=yT;

%% PID Control, Analysis of the transfer functions.
D=tf([3.6 3 0.6],[1 0]);
L=series(G,D);
T=feedback(L,1);
S=1-T;
Tw=series(Gw*G,S);
yT=step(T,t);
yW=step(Tw,t);
figure(8)
clf
set(gcf,'name','PID Control T')
plot(t,yT,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
figure(9)
clf
set(gcf,'name','PID Control Tw')
plot(t,yW,t,t*0+1);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
set(gca,'children',[lines(2),lines(1)]);
yT_PID=yT;

%% Combined simulation results
figure(10)
clf
set(gcf,'name','All controllers T')
plot(t,yT_P,t,t*0+1,t,yT_PI,t,yT_PD,t,yT_PID);
ylim([0,1.6]);
xlabel('t')
ylabel('y(t)');
lines=get(gca,'children');
set(lines,'linewidth',2)
