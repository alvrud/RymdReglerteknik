x10 = 0.5;
x20 = 0.5;
rho = delta;
tau1 = 2*sqrt(x10)/gamma1;
tau2 = 2*sqrt(x20)/gamma2;
%q = omega^2*tau1*tau2*(1+2*alpha*zeta)-1;
%K = q/rho/tau2;
%Ti = q/alpha/omega^3/tau1/tau2;
%Td = (omega*tau1*tau2*(alpha+2*zeta)-tau1-tau2)/q;

q = omega*tau1*tau2*(omega+2*alpha*zeta)-1;
K = q/rho/tau2;
Ti = q/alpha/omega^2/tau1/tau2;
Td = (tau1*tau2*(alpha+2*zeta*omega)-tau1-tau2)/q;
fprintf('K = %0.3f   Ti = %0.3f Td = %0.3f\n',K,Ti,Td);