x10 = 0.5;
x20 = 0.5;
rho = delta;
tau1 = 2*sqrt(x10)/gamma1;
tau2 = 2*sqrt(x20)/gamma2;
K = (2*zeta*omega*tau1-1)/rho/tau1;
Ti = K*rho/omega^2;
fprintf('K = %0.3f   Ti = %0.3f\n',K,Ti);